# Ruta Ventas
App Android para vendedor de ruta. Guarda clientes, sus notas y ubicación GPS; permite abrir la ubicación en Google Maps y visualizar los clientes guardados en un mapa. No registra importes de venta.

Proyecto preparado para Android Studio.
