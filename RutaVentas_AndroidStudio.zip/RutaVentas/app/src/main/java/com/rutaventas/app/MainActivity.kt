package com.rutaventas.app
import android.Manifest
import android.app.*
import android.os.Bundle
import android.content.*
import android.content.pm.PackageManager
import android.location.*
import android.net.Uri
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import org.json.*

data class Cliente(val nombre:String,val nota:String,val lat:Double?,val lon:Double?)
class MainActivity:AppCompatActivity(){
 private val permiso=7; private val prefs by lazy{getSharedPreferences("ruta",0)}; private val clientes=mutableListOf<Cliente>(); private var ubicacion:Location?=null
 lateinit var nombre:EditText; lateinit var nota:EditText; lateinit var estado:TextView; lateinit var lista:ListView
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);nombre=findViewById(R.id.name);nota=findViewById(R.id.note);estado=findViewById(R.id.status);lista=findViewById(R.id.list);cargar();refrescar()
 findViewById<Button>(R.id.location).setOnClickListener{obtener()};findViewById<Button>(R.id.save).setOnClickListener{guardar()};findViewById<Button>(R.id.map).setOnClickListener{mapa()}
 lista.setOnItemClickListener{_,_,i,_->val c=clientes[i];if(c.lat!=null)startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/maps/search/?api=1&query=${c.lat},${c.lon}")))else Toast.makeText(this,"Este cliente no tiene ubicación",Toast.LENGTH_SHORT).show()}
 if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),permiso)}
 private fun obtener(){if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),permiso);return};val lm=getSystemService(LOCATION_SERVICE) as LocationManager;var best:Location?=null;for(p in lm.getProviders(true)){val x=lm.getLastKnownLocation(p);if(x!=null&&(best==null||x.accuracy<best!!.accuracy))best=x};ubicacion=best;estado.text=if(best!=null)"Ubicación lista: %.5f, %.5f".format(best!!.latitude,best!!.longitude)else"Activa el GPS y vuelve a intentar"}
 private fun guardar(){val n=nombre.text.toString().trim();if(n.isEmpty()){nombre.error="Escribe el nombre";return};if(ubicacion==null)obtener();val x=ubicacion;clientes.add(Cliente(n,nota.text.toString().trim(),x?.latitude,x?.longitude));persistir();refrescar();nombre.text.clear();nota.text.clear();ubicacion=null;estado.text="Cliente guardado."}
 private fun refrescar(){lista.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,clientes.map{"👤 ${it.nombre}\n${it.nota.ifBlank{"Sin dirección"}}${if(it.lat!=null)"\n📍 Ubicación guardada" else "\n⚠️ Sin ubicación"}})}
 private fun persistir(){val a=JSONArray();clientes.forEach{c->a.put(JSONObject().apply{put("n",c.nombre);put("d",c.nota);if(c.lat!=null)put("lat",c.lat);if(c.lon!=null)put("lon",c.lon)})};prefs.edit().putString("clientes",a.toString()).apply()}
 private fun cargar(){val a=JSONArray(prefs.getString("clientes","[]"));for(i in 0 until a.length()){val o=a.getJSONObject(i);clientes.add(Cliente(o.getString("n"),o.optString("d"),if(o.has("lat"))o.getDouble("lat")else null,if(o.has("lon"))o.getDouble("lon")else null))}}
 private fun mapa(){val pts=clientes.filter{it.lat!=null&&it.lon!=null};val html="""<!doctype html><html><head><meta name="viewport" content="width=device-width"><link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"><style>html,body,#m{height:100%;margin:0}</style></head><body><div id="m"></div><script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script><script>let p=${pts.map{"{n:${JSONObject.quote(it.nombre)},a:${it.lat},o:${it.lon}}"}};let m=L.map('m').setView(p.length?[p[0].a,p[0].o]:[-12.2,-76.94],14);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap'}).addTo(m);p.forEach(x=>L.marker([x.a,x.o]).addTo(m).bindPopup(x.n));</script></body></html>""";val w=WebView(this);w.settings.javaScriptEnabled=true;w.webViewClient=WebViewClient();setContentView(w);w.loadDataWithBaseURL("https://ruta.local/",html,"text/html","UTF-8",null)}
}
